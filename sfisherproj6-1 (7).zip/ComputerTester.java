import javax.swing.JFrame;


public class ComputerTester {

	public static void main(String[] args) {
		ComputerOrderCalculation cO = new ComputerOrderCalculation();
		cO.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cO.setSize(500, 300);
		cO.setVisible(true);
		

	}

}
